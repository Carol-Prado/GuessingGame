// alert - document.write - console.log
var secretNum = parseInt(Math.random() * 10)
//alert(secretNum)
var tries = 3

while (tries > 0) {
  var guess = parseInt(prompt("Type a number between 0 to 10"))

  if (secretNum == guess) {
    alert("You win!")
    break
  } else if (guess > secretNum) {
    alert("The secret number is less than the number entered.")
    tries = tries - 1
  } else if (guess < secretNum) {
    alert("The secret number is bigger than the number entered.")
    tries = tries - 1
  } 
}

if (guess != secretNum){
  alert("Game Over. The secret number was " + secretNum)
}